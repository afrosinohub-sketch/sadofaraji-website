# Sado Faraji — Tovuti Rasmi ya Mwandishi

Tovuti ya kisasa ya Sado Faraji — mwandishi na mwanahistoria kutoka Dar es Salaam, Tanzania.

## Teknologia

- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **UI**: shadcn/ui (New York style)
- **Fonts**: Playfair Display + Inter (Google Fonts)

## Sehemu za Tovuti

1. **Hero** — Jina la mwandishi na vitabu 3 vya featured
2. **Vimechapishwa Hivi Karibuni** — Vitabu vipya
3. **Maktaba ya Vitabu** — Vitabu 16 vyote, yenye filter ya kategoria
4. **Makala** — Makala za hivi karibuni
5. **Kuhusu Mwandishi** — Bio kamili
6. **Platforms za Mauzo** — Amazon + Draft2Digital
7. **Wasiliana** — Email link

## Maudhui

- **Vitabu 16** vinavyouzwa kwenye Amazon
- **Links za Amazon Author Store**: https://www.amazon.com/stores/Sado-Faraji/author/B0G5BR5YLF
- **Links za Draft2Digital (Books2Read)**: https://books2read.com/ap/xy0Abp/Sado-Faraji
- **Email**: info@sadofaraji.com
- **Domain**: sadofaraji.com

## Maendeleo ya Local

```bash
# Install dependencies
bun install

# Run dev server
bun run dev

# Build for production
bun run build

# Lint
bun run lint
```

## Deployment

Ona `DEPLOYMENT.md` kwa mwongozo kamili wa ku-deploy kwenye Vercel + custom domain.

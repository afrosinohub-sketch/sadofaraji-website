export type Book = {
  id: string;
  title: string;
  subtitle: string;
  genre: string;
  category: "Ujasusi" | "Historia" | "Teknolojia" | "Fiksi" | "Dini" | "Siasa" | "Fantasy" | "Tamthilia";
  description: string;
  series?: string;
  formats: string[];
  price: string;
  gradient: string;
  accent: string;
  pattern: "arabic" | "geometric" | "wave" | "stars" | "grid" | "flame";
  featured?: boolean;
  newRelease?: boolean;
};

// Links za mauzo za pamoja
export const AMAZON_AUTHOR_URL =
  "https://www.amazon.com/stores/Sado-Faraji/author/B0G5BR5YLF?ref=ap_rdr&shoppingPortalEnabled=true&ccs_id=299f89de-9f09-4b49-a1fc-b10fc8154cc9";
export const BOOKS2READ_URL = "https://books2read.com/ap/xy0Abp/Sado-Faraji";
export const WEBSITE_URL = "https://sadofaraji.com/";
export const EMAIL = "info@sadofaraji.com";

export const books: Book[] = [
  {
    id: "oktoba-29",
    title: "Oktoba 29 na Vita vya Algorithm",
    subtitle: "Ujasusi wa Kisasa: Teknolojia, Propaganda na Rasilimali Dhidi ya Uhuru wa Mataifa",
    genre: "Ujasusi · Siasa · Teknolojia",
    category: "Ujasusi",
    description:
      "Uchunguzi wa kina juu ya jinsi teknolojia, propaganda na rasilimali zinavyotumika kudhoofisha uhuru wa mataifa. Kitabu hiki kinabainisha mbinu mpya za ujasusi wa kisasa na athari zake kwa jamii.",
    series: "Digital Insurrection",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-amber-900 via-orange-950 to-stone-950",
    accent: "amber-400",
    pattern: "grid",
    featured: true,
    newRelease: true,
  },
  {
    id: "spirit-of-resistance",
    title: "Spirit of Resistance",
    subtitle: "The Legend of Mkwawa — The untold story of resistance against colonial oppression in East Africa",
    genre: "Historical Biography",
    category: "Historia",
    description:
      "Hadithi isiyosahaulika ya Mkwawa na upinzani wake dhidi ya ukoloni nchini Tanzania. Kitabu hiki kinarejesha sauti za mashujaa wa Afrika Mashariki waliosahaulika.",
    series: "Defiance Legacy",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-red-950 via-rose-950 to-stone-950",
    accent: "rose-400",
    pattern: "flame",
    featured: true,
  },
  {
    id: "blind-obedience",
    title: "Blind Obedience",
    subtitle: "Conscience, Faith, and the Quiet Danger of Obedience Without Question",
    genre: "Religious Critique · Faith",
    category: "Dini",
    description:
      "Uchambuzi wa kina wa hatari ya kutii bila kuhoji. Kitabu hiki kinachunguza uhusiano kati ya dini, imani na uhuru wa mawazo.",
    series: "Blind Obedience Series",
    formats: ["Kindle", "Paperback"],
    price: "$5.99",
    gradient: "from-stone-800 via-stone-900 to-black",
    accent: "amber-300",
    pattern: "arabic",
    featured: true,
  },
  {
    id: "binding-of-ash",
    title: "The Binding of Ash and Storm",
    subtitle: "A Polyamorous Fantasy Romance — where fire, ash, and forbidden bonds collide",
    genre: "Fantasy Romance",
    category: "Fantasy",
    description:
      "Riwaya ya kipekee ya mapenzi na fantasia inayochanganya moto, majivu na mahusiano yaliyokataliwa. Hadithi inayovuka mipaka ya utamaduni na desturi.",
    series: "The Trinity Chronicles: Book One",
    formats: ["Kindle", "Paperback"],
    price: "$2.99",
    gradient: "from-purple-950 via-fuchsia-950 to-slate-950",
    accent: "fuchsia-400",
    pattern: "stars",
  },
  {
    id: "djinn-prince-pact",
    title: "The Djinn Prince's Pact",
    subtitle: "A Romantasy of Legacy and Whispers — ancient pacts, forbidden power, and destiny",
    genre: "Romantasy · Fantasy",
    category: "Fantasy",
    description:
      "Mapatano ya kale, nguvu iliyokataliwa na hatima. Riwaya inayochanganya fantasia, mapenzi na hadithi za Kiislamu za majini.",
    series: "The Eternal Pact Volume 1",
    formats: ["Kindle", "Paperback"],
    price: "$3.99",
    gradient: "from-emerald-950 via-teal-950 to-slate-950",
    accent: "emerald-400",
    pattern: "arabic",
    featured: true,
  },
  {
    id: "indelible-archive",
    title: "The Indelible Archive",
    subtitle: "When the Erased Refuse to Stay Silent — A powerful narrative of memory and resistance",
    genre: "Literary Fiction",
    category: "Fiksi",
    description:
      "Riwaya yenye nguvu kuhusu kumbukumbu na upinzani. Wakati waliofutwa wanakataa kunyamaza, hadithi inazaliwa.",
    series: "The Indelible Archive",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-slate-800 via-slate-900 to-black",
    accent: "cyan-300",
    pattern: "geometric",
  },
  {
    id: "shadows-desert",
    title: "Shadows of the Desert",
    subtitle: "The Role of Zionism in the Birth of Saudi Arabia — An investigative historical analysis",
    genre: "Middle East History",
    category: "Historia",
    description:
      "Uchunguzi wa kihistoria juu ya jukumu la Uzayuni katika kuzaliwa kwa Saudi Arabia. Kitabu kinabainisha uhusiano wa siri wa siasa na dini.",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-yellow-900 via-amber-950 to-stone-950",
    accent: "yellow-400",
    pattern: "wave",
    featured: true,
  },
  {
    id: "caliphate-foundations",
    title: "Caliphate and the Foundations of Dispute",
    subtitle: "The Role of Umar Ibn al-Khattab in Shaping the Political Legacy of the Prophet",
    genre: "Islamic History",
    category: "Dini",
    description:
      "Uchambuzi wa kisomi wa jukumu la Umar Ibn al-Khattab katika kuunda urithi wa kisiasa wa Mtume. Kitabu kinazua maswali muhimu ya mamlaka na dini.",
    series: "Architecture of Power",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-green-950 via-emerald-950 to-black",
    accent: "green-400",
    pattern: "arabic",
  },
  {
    id: "mtego-wa-kafara",
    title: "Mtego wa Kafara",
    subtitle: "Jinsi Vijana Walivyogeuzwa Silaha Dhidi ya Jamhuri",
    genre: "Swahili Literature",
    category: "Tamthilia",
    description:
      "Riwaya ya Kiswahili inayochunguza jinsi vijana wanavyotumiwa kama silaha za kisiasa dhidi ya jamhuri. Hadithi inayogusa ukweli wa siasa za Tanzania.",
    series: "Mtego wa Kafara Series",
    formats: ["Kindle", "Paperback"],
    price: "$3.99",
    gradient: "from-red-900 via-rose-950 to-stone-950",
    accent: "orange-400",
    pattern: "flame",
  },
  {
    id: "digital-insurrection",
    title: "Digital Insurrection",
    subtitle: "The Collapse of Truth — How Information Warfare, AI Manipulation, and Psychological Control Are Reshaping Humanity",
    genre: "Political Analysis",
    category: "Teknolojia",
    description:
      "Vita vya habari, udhibiti wa AI na udhibiti wa kisaikolojia. Kitabu kinachunguza jinsi ukweli unavyoporomoka na ubinadamu unavyobadilika.",
    formats: ["Kindle"],
    price: "$4.99",
    gradient: "from-cyan-950 via-blue-950 to-slate-950",
    accent: "cyan-400",
    pattern: "grid",
  },
  {
    id: "bridge-hope-sorrow",
    title: "The Bridge of Hope and Sorrow",
    subtitle: "A moving tale exploring the journey between hope and heartbreak",
    genre: "Fiction",
    category: "Fiksi",
    description:
      "Hadithi inayogusa moyo kuhusu safari kati ya tumaini na maumivu. Riwaya inayochunguza nguvu ya mapenzi na uvumilivu.",
    formats: ["Kindle"],
    price: "$4.99",
    gradient: "from-indigo-950 via-violet-950 to-slate-950",
    accent: "violet-400",
    pattern: "wave",
  },
  {
    id: "ink-between",
    title: "The Ink Between",
    subtitle: "When the Erased Refuse to Stay Silent",
    genre: "Literary Fiction",
    category: "Fiksi",
    description:
      "Riwaya ya kifasihi inayochunguza kumbukumbu, utambulisho na upinzani. Wakati waliofutwa wanakataa kunyamaza.",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-stone-700 via-stone-900 to-black",
    accent: "amber-300",
    pattern: "geometric",
  },
  {
    id: "ai-detox",
    title: "The 90-Day AI Detox",
    subtitle: "Break Free from ChatGPT, TikTok, and Endless Digital Dependence",
    genre: "Teknolojia · Maisha",
    category: "Teknolojia",
    description:
      "Mwongozo wa siku 90 wa kujikomboa kutoka tegemezi la AI, TikTok na simu. Hatua za kwenda kwenye uhuru wa kidijitali.",
    formats: ["Kindle"],
    price: "$4.99",
    gradient: "from-teal-900 via-cyan-950 to-slate-950",
    accent: "teal-300",
    pattern: "grid",
    newRelease: true,
  },
  {
    id: "cultural-shadow",
    title: "The Seven Laws of Cultural Shadow Power",
    subtitle: "How to Read, Navigate, and Master Hidden Cultural Forces",
    genre: "Siasa · Jamii",
    category: "Siasa",
    description:
      "Sheria saba za nguvu za kifomune za utamaduni. Kitabu kinachofundisha jinsi ya kusoma, kuabiri na kutumia nguvu za siri za kijamii.",
    formats: ["Kindle"],
    price: "$9.99",
    gradient: "from-amber-800 via-orange-950 to-stone-950",
    accent: "amber-400",
    pattern: "geometric",
  },
  {
    id: "power-whisper",
    title: "Power Whisper",
    subtitle: "8 Laws of Influence That History Tried to Hide",
    genre: "Siasa · Historia",
    category: "Siasa",
    description:
      "Sheria nane za ushawishi ambazo historia ilijaribu kuficha. Ufahamu wa nguvu za siri zilizotumika karne nyingi.",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-rose-950 via-red-950 to-black",
    accent: "rose-400",
    pattern: "flame",
  },
  {
    id: "mirror-states",
    title: "The Mirror States",
    subtitle: "Saudi Arabia, Israel, and the Architecture of Betrayal",
    genre: "Siasa · Historia",
    category: "Siasa",
    description:
      "Uchunguzi wa kina wa uhusiano kati ya Saudi Arabia na Israeli. Usanifu wa khiana katika siasa za Mashariki ya Kati.",
    formats: ["Kindle", "Paperback"],
    price: "$4.99",
    gradient: "from-stone-900 via-yellow-950 to-black",
    accent: "yellow-300",
    pattern: "arabic",
  },
];

export type Article = {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  date: string;
  accent: string;
};

export const articles: Article[] = [
  {
    id: "vita-visivyoonekana",
    title: "“Vita Visivyoonekana”: CIA, Hybrid Warfare na Propaganda",
    excerpt:
      "Kutoka Angola hadi Syria — jinsi mataifa yanavyovamiwa kwa propaganda, mapinduzi na migogoro ya ndani. Uchambuzi wa Vita Bara vya siri vya CIA.",
    category: "Siasa · Historia · Usalama",
    readTime: "Dakika 15",
    date: "2025",
    accent: "rose",
  },
  {
    id: "warioba-mange-khalifa",
    title: "Ya Warioba, Mange na Khalifa: Tanzania Moja, Ulimwengu Mitatu",
    excerpt:
      "Mgawanyiko ambao hauonekani kwa macho — lakini unasikika kwenye kila mjadala wa kisiasa nchini Tanzania. Uchambuzi wa jamii tatu za Tanzania.",
    category: "Siasa · Jamii · Vizazi",
    readTime: "Dakika 10",
    date: "2025",
    accent: "amber",
  },
];

export const categories = [
  "Vyote",
  "Historia",
  "Dini",
  "Fantasy",
  "Fiksi",
  "Ujasusi",
  "Siasa",
  "Teknolojia",
  "Tamthilia",
] as const;

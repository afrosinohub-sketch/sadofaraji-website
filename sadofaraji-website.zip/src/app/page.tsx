"use client";

import { useState, useMemo, useEffect } from "react";
import { BookCover } from "@/components/book-cover";
import {
  books,
  articles,
  categories,
  AMAZON_AUTHOR_URL,
  BOOKS2READ_URL,
  WEBSITE_URL,
  EMAIL,
  type Book,
} from "@/lib/books";
import { cn } from "@/lib/utils";
import {
  BookOpen,
  Feather,
  Library,
  Mail,
  Menu,
  X,
  ShoppingCart,
  Globe,
  Sparkles,
  ArrowRight,
  ArrowUpRight,
  PenTool,
  ScrollText,
  Quote,
  Calendar,
  Clock,
  MapPin,
  Languages,
} from "lucide-react";

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<string>("Vyote");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const filteredBooks = useMemo(() => {
    if (activeCategory === "Vyote") return books;
    return books.filter((b) => b.category === activeCategory);
  }, [activeCategory]);

  const featuredBooks = books.filter((b) => b.featured).slice(0, 3);
  const newReleases = books.filter((b) => b.newRelease);

  const navLinks = [
    { href: "#vitabu", label: "Vitabu" },
    { href: "#makala", label: "Makala" },
    { href: "#kuhusu", label: "Kuhusu" },
    { href: "#mauzo", label: "Mauzo" },
    { href: "#wasiliana", label: "Wasiliana" },
  ];

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 selection:bg-amber-500/30">
      {/* ===== Header ===== */}
      <header
        className={cn(
          "fixed top-0 inset-x-0 z-50 transition-all duration-300",
          scrolled
            ? "bg-stone-950/85 backdrop-blur-xl border-b border-amber-900/30"
            : "bg-transparent"
        )}
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 sm:h-20 items-center justify-between">
            {/* Logo */}
            <a href="#home" className="group flex items-center gap-3">
              <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-full border border-amber-500/40 bg-stone-900">
                <span className="font-serif text-xl sm:text-2xl font-bold text-amber-400">
                  SF
                </span>
              </div>
              <div className="hidden sm:block">
                <div className="font-serif text-base font-semibold text-stone-100 leading-tight">
                  Sado Faraji
                </div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-amber-500/70">
                  Mwandishi · Mwanahistoria
                </div>
              </div>
            </a>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="rounded-md px-3 py-2 text-sm font-medium text-stone-300 transition-colors hover:bg-amber-500/10 hover:text-amber-400"
                >
                  {link.label}
                </a>
              ))}
              <a
                href={AMAZON_AUTHOR_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-2 inline-flex items-center gap-1.5 rounded-md bg-amber-500 px-4 py-2 text-sm font-semibold text-stone-950 transition-colors hover:bg-amber-400"
              >
                <ShoppingCart className="h-4 w-4" />
                Nunua Vitabu
              </a>
            </nav>

            {/* Mobile toggle */}
            <button
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="md:hidden rounded-md p-2 text-stone-300 hover:bg-amber-500/10 hover:text-amber-400"
              aria-label="Fungua menyu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-amber-900/30 bg-stone-950/95 backdrop-blur-xl">
            <nav className="mx-auto max-w-7xl px-4 py-4 flex flex-col gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-md px-3 py-3 text-base font-medium text-stone-300 hover:bg-amber-500/10 hover:text-amber-400"
                >
                  {link.label}
                </a>
              ))}
              <a
                href={AMAZON_AUTHOR_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-flex items-center justify-center gap-2 rounded-md bg-amber-500 px-4 py-3 text-base font-semibold text-stone-950"
              >
                <ShoppingCart className="h-5 w-5" />
                Nunua Vitabu
              </a>
            </nav>
          </div>
        )}
      </header>

      {/* ===== Hero ===== */}
      <section
        id="home"
        className="relative overflow-hidden pt-32 sm:pt-40 pb-20 sm:pb-28"
      >
        {/* Background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-stone-900 via-stone-950 to-stone-950" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(245,158,11,0.12),transparent_60%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(220,38,38,0.08),transparent_50%)]" />
          <div className="absolute inset-0 opacity-[0.04] bg-[linear-gradient(rgba(245,158,11,0.5)_1px,transparent_1px),linear-gradient(90deg,rgba(245,158,11,0.5)_1px,transparent_1px)] [background-size:48px_48px]" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Left: Text */}
            <div className="lg:col-span-7 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/5 px-4 py-1.5 text-xs uppercase tracking-[0.18em] text-amber-400">
                <Sparkles className="h-3.5 w-3.5" />
                Tovuti Rasmi ya Mwandishi
              </div>

              <h1 className="mt-6 font-serif text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold leading-[1.05] tracking-tight">
                <span className="block text-stone-100">Sado</span>
                <span className="block bg-gradient-to-r from-amber-300 via-amber-400 to-orange-400 bg-clip-text text-transparent">
                  Faraji
                </span>
              </h1>

              <p className="mt-4 font-serif text-lg sm:text-xl italic text-stone-300">
                Author · Historian · Critical Thinker
              </p>

              <p className="mx-auto lg:mx-0 mt-8 max-w-2xl text-base sm:text-lg leading-relaxed text-stone-300">
                Kutoka Dar es Salaam, Tanzania — mwandishi anayechunguza historia,
                imani, na hadithi. Kazi yake inachanganya usomi wa Kiislamu,
                ukosoaji wa utamaduni, na fiksi ya kimithili kuibua maswali ya
                nguvu, upinzani, na hadhi ya binadamu.
              </p>

              <div className="mt-10 flex flex-wrap gap-3 justify-center lg:justify-start">
                <a
                  href={AMAZON_AUTHOR_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group inline-flex items-center gap-2 rounded-md bg-amber-500 px-6 py-3 text-sm sm:text-base font-semibold text-stone-950 transition-all hover:bg-amber-400 hover:shadow-lg hover:shadow-amber-500/30"
                >
                  <ShoppingCart className="h-5 w-5" />
                  Nunua kwenye Amazon
                  <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
                <a
                  href={BOOKS2READ_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group inline-flex items-center gap-2 rounded-md border border-amber-500/40 bg-stone-900/50 px-6 py-3 text-sm sm:text-base font-semibold text-amber-400 transition-all hover:bg-amber-500/10"
                >
                  <Globe className="h-5 w-5" />
                  Draft2Digital
                  <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
              </div>

              {/* Stats */}
              <div className="mt-12 grid grid-cols-3 gap-4 sm:gap-8 max-w-lg mx-auto lg:mx-0">
                {[
                  { value: `${books.length}+`, label: "Vitabu" },
                  { value: "8+", label: "Aina za Faksi" },
                  { value: "2", label: "Platforms za Mauzo" },
                ].map((s) => (
                  <div key={s.label} className="text-center lg:text-left">
                    <div className="font-serif text-3xl sm:text-4xl font-bold text-amber-400">
                      {s.value}
                    </div>
                    <div className="mt-1 text-xs sm:text-sm text-stone-400">
                      {s.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Featured book stack */}
            <div className="lg:col-span-5">
              <div className="relative mx-auto max-w-md">
                {/* Glow */}
                <div className="absolute -inset-8 bg-gradient-to-br from-amber-500/20 via-orange-500/10 to-transparent rounded-full blur-3xl" />

                {/* Featured books grid - desktop only */}
                <div className="relative hidden sm:grid grid-cols-3 gap-3 py-6">
                  {featuredBooks.map((book, i) => (
                    <a
                      key={book.id}
                      href={AMAZON_AUTHOR_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={cn(
                        "relative transition-all duration-300 hover:scale-105 hover:z-10",
                        i === 1 && "-translate-y-3 sm:-translate-y-4"
                      )}
                    >
                      <BookCover book={book} />
                    </a>
                  ))}
                </div>

                {/* Mobile: single featured book */}
                <div className="sm:hidden mt-4">
                  <a
                    href={AMAZON_AUTHOR_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block max-w-[200px] mx-auto transition-transform hover:scale-105"
                  >
                    <BookCover book={featuredBooks[0]} />
                  </a>
                </div>

                {/* Floating quote */}
                <div className="mt-10 rounded-lg border border-amber-900/40 bg-stone-900/60 p-5 backdrop-blur-sm">
                  <Quote className="h-5 w-5 text-amber-500/70" />
                  <p className="mt-2 font-serif italic text-stone-200">
                    “Kazi yake inachanganya historia, imani, na hadithi — ikijaribu
                    kuelewa mgongano kati ya mapokeo na udunia.”
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Featured / New Releases ===== */}
      {newReleases.length > 0 && (
        <section className="border-y border-amber-900/20 bg-gradient-to-b from-stone-950 to-stone-900/40 py-16 sm:py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-end justify-between mb-10">
              <div>
                <div className="inline-flex items-center gap-2 text-amber-400 text-xs uppercase tracking-[0.2em]">
                  <Sparkles className="h-4 w-4" />
                  Vipya
                </div>
                <h2 className="mt-3 font-serif text-3xl sm:text-4xl font-bold text-stone-100">
                    Vimechatishwa Hivi Karibuni
                </h2>
              </div>
              <a
                href="#vitabu"
                className="hidden sm:inline-flex items-center gap-1.5 text-sm text-amber-400 hover:text-amber-300"
              >
                Soma vitabu vyote <ArrowRight className="h-4 w-4" />
              </a>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {newReleases.map((book) => (
                <FeaturedBookCard key={book.id} book={book} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ===== Books Library ===== */}
      <section id="vitabu" className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Section header */}
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 text-amber-400 text-xs uppercase tracking-[0.2em]">
              <Library className="h-4 w-4" />
              Maktaba ya Vitabu
            </div>
            <h2 className="mt-3 font-serif text-4xl sm:text-5xl font-bold text-stone-100">
              Vitabu Vilivyochapishwa
            </h2>
            <p className="mt-4 text-base sm:text-lg text-stone-400">
              Vitabu vinavyoshughulikia historia, dini, siasa, fiksi na fantasia.
              Kila kitabu kiko wazi kwa kununua kwenye Amazon na Draft2Digital.
            </p>
          </div>

          {/* Filter tabs */}
          <div className="mt-10 flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={cn(
                  "rounded-full border px-4 py-1.5 text-sm font-medium transition-all",
                  activeCategory === cat
                    ? "border-amber-500 bg-amber-500 text-stone-950"
                    : "border-stone-700 bg-stone-900/50 text-stone-300 hover:border-amber-500/50 hover:text-amber-400"
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Books grid */}
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5 sm:gap-6">
            {filteredBooks.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>

          {filteredBooks.length === 0 && (
            <div className="mt-16 text-center text-stone-500">
              Hakuna kitabu katika kategoria hii.
            </div>
          )}

          {/* CTA bar */}
          <div className="mt-16 overflow-hidden rounded-2xl border border-amber-900/30 bg-gradient-to-r from-stone-900 via-stone-900 to-amber-950/30 p-6 sm:p-10">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-100">
                  Una maswali kuhusu kitabu chochote?
                </h3>
                <p className="mt-2 text-stone-400">
                  Wasiliana nasi kwa maoni, maombi, au mada jipya unayotaka
                  kusoma.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <a
                  href={AMAZON_AUTHOR_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-md bg-amber-500 px-5 py-2.5 text-sm font-semibold text-stone-950 hover:bg-amber-400"
                >
                  <ShoppingCart className="h-4 w-4" />
                  Amazon
                </a>
                <a
                  href={BOOKS2READ_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-md border border-amber-500/40 bg-stone-900/60 px-5 py-2.5 text-sm font-semibold text-amber-400 hover:bg-amber-500/10"
                >
                  <Globe className="h-4 w-4" />
                  Draft2Digital
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Articles / Makala ===== */}
      <section
        id="makala"
        className="relative py-20 sm:py-28 border-t border-amber-900/20 bg-gradient-to-b from-stone-900/40 to-stone-950"
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 text-amber-400 text-xs uppercase tracking-[0.2em]">
              <PenTool className="h-4 w-4" />
              Makala
            </div>
            <h2 className="mt-3 font-serif text-4xl sm:text-5xl font-bold text-stone-100">
              Makala za Hivi Karibuni
            </h2>
            <p className="mt-4 text-base sm:text-lg text-stone-400">
              Uchambuzi wa kina wa siasa, historia, na jamui. Makala zinazochunguza
              mada changamano kwa macho ya kihistoria na ukosoaji wa kifalsafa.
            </p>
          </div>

          <div className="mt-12 grid md:grid-cols-2 gap-6 items-stretch">
            {articles.map((article) => (
              <article
                key={article.id}
                className="group relative flex flex-col overflow-hidden rounded-2xl border border-stone-800 bg-stone-900/40 p-6 sm:p-8 transition-all hover:border-amber-500/40 hover:bg-stone-900/70"
              >
                {/* Decorative line */}
                <div
                  className={cn(
                    "absolute top-0 left-0 h-1 w-full bg-gradient-to-r",
                    article.accent === "rose"
                      ? "from-rose-500 to-amber-500"
                      : "from-amber-500 to-orange-500"
                  )}
                />

                <div className="flex items-center gap-3 text-xs text-stone-400">
                  <span
                    className={cn(
                      "rounded-full px-2.5 py-1 font-medium",
                      article.accent === "rose"
                        ? "bg-rose-500/10 text-rose-300"
                        : "bg-amber-500/10 text-amber-300"
                    )}
                  >
                    {article.category}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" /> {article.date}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" /> {article.readTime}
                  </span>
                </div>

                <h3 className="mt-5 font-serif text-2xl sm:text-3xl font-bold leading-tight text-stone-100 group-hover:text-amber-300 transition-colors">
                  {article.title}
                </h3>

                <p className="mt-4 text-stone-300 leading-relaxed flex-1">
                  {article.excerpt}
                </p>

                <a
                  href={WEBSITE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-amber-400 hover:text-amber-300"
                >
                  Soma zaidi <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </article>
            ))}
          </div>

          <div className="mt-10 text-center">
            <a
              href={WEBSITE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md border border-amber-500/40 bg-stone-900/60 px-6 py-3 text-sm font-semibold text-amber-400 transition-all hover:bg-amber-500/10"
            >
              <ScrollText className="h-4 w-4" />
              Soma Makala Zote
              <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      {/* ===== About ===== */}
      <section id="kuhusu" className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Portrait side */}
            <div className="lg:col-span-5 order-2 lg:order-1">
              <div className="relative mx-auto max-w-sm">
                {/* Frame */}
                <div className="absolute -inset-3 rounded-2xl border border-amber-500/30" />
                <div className="absolute -inset-6 rounded-2xl border border-amber-500/10" />

                {/* Portrait placeholder */}
                <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-gradient-to-br from-stone-800 via-stone-900 to-stone-950 ring-1 ring-amber-500/20">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(245,158,11,0.15),transparent_60%)]" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
                    <div className="flex h-32 w-32 sm:h-40 sm:w-40 items-center justify-center rounded-full border-2 border-amber-500/40 bg-stone-900">
                      <span className="font-serif text-6xl sm:text-7xl font-bold text-amber-400">
                        SF
                      </span>
                    </div>
                    <div className="mt-6 font-serif text-xl font-semibold text-stone-200">
                      Sado Faraji
                    </div>
                    <div className="mt-1 text-xs uppercase tracking-[0.2em] text-amber-500/70">
                      Dar es Salaam · Tanzania
                    </div>
                  </div>
                </div>

                {/* Floating tag */}
                <div className="absolute -bottom-4 -right-4 rounded-lg border border-amber-500/30 bg-stone-900 px-4 py-2 shadow-xl">
                  <div className="text-[10px] uppercase tracking-widest text-stone-400">
                    Tangu
                  </div>
                  <div className="font-serif text-xl font-bold text-amber-400">2024</div>
                </div>
              </div>
            </div>

            {/* Text side */}
            <div className="lg:col-span-7 order-1 lg:order-2">
              <div className="inline-flex items-center gap-2 text-amber-400 text-xs uppercase tracking-[0.2em]">
                <Feather className="h-4 w-4" />
                Kuhusu Mwandishi
              </div>
              <h2 className="mt-3 font-serif text-4xl sm:text-5xl font-bold text-stone-100">
                Kuhusu Sado Faraji
              </h2>

              <div className="mt-6 space-y-4 text-stone-300 leading-relaxed">
                <p>
                  <span className="font-serif text-amber-400 text-lg">SADO FARAJI</span>{" "}
                  ni mwandishi na mwanahistoria kutoka Dar es Salaam, Tanzania.
                  Kazi yake inachanganya historia, imani, na hadithi — ikijenga
                  daraja kati ya usomi wa Kiislamu, ukosoaji wa utamaduni, na
                  fiksi ya kimithili.
                </p>
                <p>
                  Kupitia riwaya, tamthilia, na kazi za kisomi, anachunguza
                  mgongano kati ya mapokeo na udunia, khiana na uaminifu, mapenzi
                  na maisha. Uandishi wake una nguvu ya kimithili — umeandikwa
                  kwa kusudi la kusikika kwa vizazi vingi na kuchochea tafakari
                  juu ya hatima ya pamoja ya ubinadamu.
                </p>
                <p>
                  Anayeandika kutoka pembezoni mwa milki, anarejesha hadithi
                  ambazo madola ya kikoloni, mamlaka za kidini, na nasaba za
                  kisiasa zilizifuta au kuzificha.
                </p>
              </div>

              {/* Quick facts */}
              <div className="mt-8 grid sm:grid-cols-2 gap-4">
                {[
                  { icon: MapPin, label: "Asili", value: "Dar es Salaam, Tanzania" },
                  { icon: BookOpen, label: "Aina za Kazi", value: "Historia · Dini · Fiksi · Fantasia" },
                  { icon: Languages, label: "Lugha", value: "Kiswahili · Kiingereza · Kiarabu" },
                  { icon: Feather, label: "Mada Kuu", value: "Nguvu · Upinzani · Hadhi" },
                ].map((fact) => (
                  <div
                    key={fact.label}
                    className="flex items-start gap-3 rounded-lg border border-stone-800 bg-stone-900/40 p-4"
                  >
                    <fact.icon className="h-5 w-5 flex-shrink-0 text-amber-400 mt-0.5" />
                    <div>
                      <div className="text-[10px] uppercase tracking-widest text-stone-400">
                        {fact.label}
                      </div>
                      <div className="mt-0.5 text-sm font-medium text-stone-200">
                        {fact.value}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Topics */}
              <div className="mt-8">
                <div className="text-xs uppercase tracking-widest text-stone-400 mb-3">
                  Mada anazoandikia
                </div>
                <div className="flex flex-wrap gap-2">
                  {[
                    "Historia ya Afrika",
                    "Ustaarabu wa Kiislamu",
                    "Haki ya Kijamii",
                    "Siasa za Mashariki ya Kati",
                    "Ukosoaji wa Dini",
                    "Fiksi ya Kimithili",
                    "Vita vya Habari",
                    "Teknolojia na Jamii",
                  ].map((topic) => (
                    <span
                      key={topic}
                      className="rounded-full border border-stone-700 bg-stone-900/50 px-3 py-1 text-xs text-stone-300"
                    >
                      {topic}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Sales Platforms ===== */}
      <section
        id="mauzo"
        className="relative py-20 sm:py-28 border-t border-amber-900/20 overflow-hidden"
      >
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-stone-950 via-amber-950/10 to-stone-950" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(245,158,11,0.06),transparent_70%)]" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-2 text-amber-400 text-xs uppercase tracking-[0.2em]">
              <ShoppingCart className="h-4 w-4" />
              Platforms za Mauzo
            </div>
            <h2 className="mt-3 font-serif text-4xl sm:text-5xl font-bold text-stone-100">
              Pakua au Nunua Vitabu
            </h2>
            <p className="mt-4 text-base sm:text-lg text-stone-400">
              Vitabu vya Sado Faraji viko wazi kwenye platforms hizi kuu. Chagua
              platform unayopendelea — kila link inakupeleka kwenye ukurasa wa
              mwandishi.
            </p>
          </div>

          <div className="mt-12 grid md:grid-cols-2 gap-6">
            {/* Amazon */}
            <a
              href={AMAZON_AUTHOR_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-br from-stone-900 to-stone-950 p-8 transition-all hover:border-amber-500/60 hover:shadow-2xl hover:shadow-amber-500/10"
            >
              <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-amber-500/10 blur-3xl" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-amber-500/10 border border-amber-500/30">
                    <ShoppingCart className="h-7 w-7 text-amber-400" />
                  </div>
                  <ArrowUpRight className="h-6 w-6 text-stone-500 transition-all group-hover:text-amber-400 group-hover:translate-x-1 group-hover:-translate-y-1" />
                </div>
                <h3 className="mt-6 font-serif text-2xl font-bold text-stone-100">
                  Amazon
                </h3>
                <p className="mt-2 text-sm text-stone-400">
                  Nunua vitabu vya Kindle na Paperback. Ukurasa rasmi wa mwandishi
                  kwenye Amazon Author Store.
                </p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {["Kindle", "Paperback", "Kindle Unlimited"].map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-stone-800/60 border border-stone-700 px-3 py-1 text-xs text-stone-300"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </a>

            {/* Draft2Digital / Books2Read */}
            <a
              href={BOOKS2READ_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-stone-900 to-stone-950 p-8 transition-all hover:border-emerald-500/60 hover:shadow-2xl hover:shadow-emerald-500/10"
            >
              <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-emerald-500/10 blur-3xl" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-emerald-500/10 border border-emerald-500/30">
                    <Globe className="h-7 w-7 text-emerald-400" />
                  </div>
                  <ArrowUpRight className="h-6 w-6 text-stone-500 transition-all group-hover:text-emerald-400 group-hover:translate-x-1 group-hover:-translate-y-1" />
                </div>
                <h3 className="mt-6 font-serif text-2xl font-bold text-stone-100">
                  Draft2Digital
                </h3>
                <p className="mt-2 text-sm text-stone-400">
                  Books2Read — unganisha vitabu vyote kwenye platforms zote:
                  Apple Books, Kobo, Barnes &amp; Noble, na zaidi.
                </p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {["Apple Books", "Kobo", "Barnes & Noble", "Scribd"].map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full bg-stone-800/60 border border-stone-700 px-3 py-1 text-xs text-stone-300"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </a>
          </div>

          {/* Mini features */}
          <div className="mt-12 grid sm:grid-cols-3 gap-4">
            {[
              {
                icon: BookOpen,
                title: "Soma Kila Mahali",
                desc: "Kwenye simu, tablet, Kindle, au kompyuta.",
              },
              {
                icon: Globe,
                title: "Platforms Nyingi",
                desc: "Chagua duki lako unalopendelea kote duniani.",
              },
              {
                icon: Sparkles,
                title: "Vitabu Vipya",
                desc: "Vimeongezwa mara kwa mara kwenye akaunti yangu.",
              },
            ].map((f) => (
              <div
                key={f.title}
                className="rounded-xl border border-stone-800 bg-stone-900/40 p-5"
              >
                <f.icon className="h-6 w-6 text-amber-400" />
                <h3 className="mt-3 font-semibold text-stone-100">{f.title}</h3>
                <p className="mt-1 text-sm text-stone-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Contact ===== */}
      <section
        id="wasiliana"
        className="py-20 sm:py-28 border-t border-amber-900/20"
      >
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 text-amber-400 text-xs uppercase tracking-[0.2em]">
            <Mail className="h-4 w-4" />
            Wasiliana
          </div>
          <h2 className="mt-3 font-serif text-4xl sm:text-5xl font-bold text-stone-100">
            Tuma Ujumbe
          </h2>
          <p className="mt-4 text-base sm:text-lg text-stone-400">
            Kwa maoni, maswali, au maombi ya mahojiano — wasiliana nasi kwa
            barua pepe. Tunajali kusikia kutoka kwako.
          </p>

          <div className="mt-10">
            <a
              href={`mailto:${EMAIL}`}
              className="inline-flex items-center gap-3 rounded-full border border-amber-500/40 bg-stone-900/60 px-6 py-4 text-base sm:text-lg font-medium text-amber-400 transition-all hover:bg-amber-500/10"
            >
              <Mail className="h-5 w-5" />
              {EMAIL}
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3 text-sm">
            <a
              href={WEBSITE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md border border-stone-700 bg-stone-900/40 px-4 py-2 text-stone-300 hover:border-amber-500/40 hover:text-amber-400"
            >
              <Globe className="h-4 w-4" />
              Tovuti Asili
            </a>
            <a
              href={AMAZON_AUTHOR_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md border border-stone-700 bg-stone-900/40 px-4 py-2 text-stone-300 hover:border-amber-500/40 hover:text-amber-400"
            >
              <ShoppingCart className="h-4 w-4" />
              Amazon
            </a>
            <a
              href={BOOKS2READ_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md border border-stone-700 bg-stone-900/40 px-4 py-2 text-stone-300 hover:border-amber-500/40 hover:text-amber-400"
            >
              <BookOpen className="h-4 w-4" />
              Books2Read
            </a>
          </div>
        </div>
      </section>

      {/* ===== Footer ===== */}
      <footer className="border-t border-amber-900/20 bg-stone-950">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full border border-amber-500/40 bg-stone-900">
                  <span className="font-serif text-lg font-bold text-amber-400">
                    SF
                  </span>
                </div>
                <div>
                  <div className="font-serif text-base font-semibold text-stone-100">
                    Sado Faraji
                  </div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-amber-500/70">
                    Author · Historian
                  </div>
                </div>
              </div>
              <p className="mt-4 text-sm text-stone-400 leading-relaxed">
                Mwandishi na mwanahistoria kutoka Dar es Salaam, Tanzania. Kazi
                zinazochunguza nguvu, upinzani, na hadhi ya binadamu.
              </p>
            </div>

            <div>
              <h4 className="text-xs uppercase tracking-widest text-stone-400">
                Navigasi
              </h4>
              <ul className="mt-4 space-y-2">
                {navLinks.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-stone-300 hover:text-amber-400"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-xs uppercase tracking-widest text-stone-400">
                Platforms
              </h4>
              <ul className="mt-4 space-y-2">
                <li>
                  <a
                    href={AMAZON_AUTHOR_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm text-stone-300 hover:text-amber-400"
                  >
                    <ShoppingCart className="h-4 w-4" /> Amazon Author Store
                  </a>
                </li>
                <li>
                  <a
                    href={BOOKS2READ_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm text-stone-300 hover:text-amber-400"
                  >
                    <Globe className="h-4 w-4" /> Books2Read (Draft2Digital)
                  </a>
                </li>
                <li>
                  <a
                    href={`mailto:${EMAIL}`}
                    className="inline-flex items-center gap-2 text-sm text-stone-300 hover:text-amber-400"
                  >
                    <Mail className="h-4 w-4" /> {EMAIL}
                  </a>
                </li>
                <li>
                  <a
                    href={WEBSITE_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm text-stone-300 hover:text-amber-400"
                  >
                    <Globe className="h-4 w-4" /> sadofaraji.com
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-500">
            <div>© {new Date().getFullYear()} Sado Faraji. Haki zote zimehifadhiwa.</div>
            <div className="flex items-center gap-1.5">
              <span className="font-serif italic">Verba volent, scripta manent.</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

// ===== Sub-components =====

function BookCard({ book }: { book: Book }) {
  return (
    <a
      href={AMAZON_AUTHOR_URL}
      target="_blank"
      rel="noopener noreferrer"
      className="group flex flex-col h-full"
    >
      <div className="relative transition-all duration-300 group-hover:-translate-y-1 group-hover:scale-[1.02]">
        <BookCover book={book} />
        {book.newRelease && (
          <span className="absolute -left-2 -top-2 z-10 rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold uppercase text-stone-950 shadow-lg">
            Vipya
          </span>
        )}
      </div>
      <div className="mt-3 flex-1 flex flex-col">
        <h3 className="font-serif text-sm font-semibold leading-tight text-stone-100 group-hover:text-amber-300 line-clamp-2">
          {book.title}
        </h3>
        <p className="mt-1 text-[11px] uppercase tracking-wider text-stone-400 line-clamp-1">
          {book.genre}
        </p>
        <div className="mt-auto pt-2 flex items-center justify-between">
          <span className="text-xs font-semibold text-amber-400">{book.price}</span>
          <span className="inline-flex items-center gap-1 text-[10px] text-stone-400 group-hover:text-amber-400">
            Nunua <ArrowUpRight className="h-3 w-3" />
          </span>
        </div>
      </div>
    </a>
  );
}

function FeaturedBookCard({ book }: { book: Book }) {
  return (
    <a
      href={AMAZON_AUTHOR_URL}
      target="_blank"
      rel="noopener noreferrer"
      className="group grid sm:grid-cols-5 gap-5 rounded-2xl border border-stone-800 bg-stone-900/40 p-5 transition-all hover:border-amber-500/40 hover:bg-stone-900/70"
    >
      <div className="sm:col-span-2 max-w-[160px] sm:max-w-none mx-auto sm:mx-0 transition-transform group-hover:scale-105">
        <BookCover book={book} />
      </div>
      <div className="sm:col-span-3 flex flex-col">
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-amber-300">
            {book.category}
          </span>
          {book.newRelease && (
            <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold uppercase text-stone-950">
              Vipya
            </span>
          )}
        </div>
        <h3 className="mt-3 font-serif text-xl sm:text-2xl font-bold leading-tight text-stone-100 group-hover:text-amber-300">
          {book.title}
        </h3>
        <p className="mt-2 font-serif italic text-sm text-stone-400">
          {book.subtitle}
        </p>
        <p className="mt-3 text-sm text-stone-300 leading-relaxed line-clamp-4">
          {book.description}
        </p>
        <div className="mt-auto pt-4 flex items-center justify-between">
          <div className="flex flex-wrap gap-1.5">
            {book.formats.map((f) => (
              <span
                key={f}
                className="rounded-md border border-stone-700 bg-stone-800/40 px-2 py-0.5 text-[10px] text-stone-300"
              >
                {f}
              </span>
            ))}
            <span className="rounded-md border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold text-amber-300">
              {book.price}
            </span>
          </div>
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-400">
            Nunua <ArrowUpRight className="h-3.5 w-3.5" />
          </span>
        </div>
      </div>
    </a>
  );
}

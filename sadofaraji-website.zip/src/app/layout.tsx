import type { Metadata } from "next";
import { Geist, Geist_Mono, Playfair_Display, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  weight: ["400", "600", "700", "800", "900"],
  style: ["normal", "italic"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Sado Faraji — Mwandishi • Mwanahistoria • Mchambuzi",
  description:
    "Tovuti rasmi ya Sado Faraji — mwandishi na mwanahistoria kutoka Dar es Salaam, Tanzania. Vitabu vya historia, dini, siasa, fiksi na fantasia. Nunua kwenye Amazon na Draft2Digital.",
  keywords: [
    "Sado Faraji",
    "vitabu",
    "makala",
    "historia",
    "Afrika",
    "Tanzania",
    "Uislamu",
    "fantasia",
    "siasa",
    "mwandishi",
  ],
  authors: [{ name: "Sado Faraji" }],
  openGraph: {
    title: "Sado Faraji — Mwandishi • Mwanahistoria",
    description:
      "Vitabu na makala za Sado Faraji. Historia, dini, siasa na fiksi. Nunua kwenye Amazon na Draft2Digital.",
    url: "https://sadofaraji.com",
    siteName: "Sado Faraji",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sado Faraji — Mwandishi • Mwanahistoria",
    description: "Vitabu na makala za Sado Faraji.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="sw" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${playfair.variable} ${inter.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

import { cn } from "@/lib/utils";
import type { Book } from "@/lib/books";

type Props = {
  book: Book;
  className?: string;
};

const patternStyles: Record<Book["pattern"], string> = {
  arabic: `bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.08),transparent_60%),radial-gradient(circle_at_70%_80%,rgba(255,255,255,0.06),transparent_50%)]`,
  geometric: `bg-[linear-gradient(45deg,rgba(255,255,255,0.04)_25%,transparent_25%,transparent_75%,rgba(255,255,255,0.04)_75%),linear-gradient(45deg,rgba(255,255,255,0.04)_25%,transparent_25%,transparent_75%,rgba(255,255,255,0.04)_75%)] [background-size:24px_24px] [background-position:0_0,12px_12px]`,
  wave: `bg-[repeating-linear-gradient(45deg,rgba(255,255,255,0.03)_0px,rgba(255,255,255,0.03)_2px,transparent_2px,transparent_12px)]`,
  stars: `bg-[radial-gradient(1px_1px_at_25%_30%,white,transparent),radial-gradient(1px_1px_at_50%_70%,white,transparent),radial-gradient(1px_1px_at_75%_20%,white,transparent),radial-gradient(1px_1px_at_15%_60%,white,transparent),radial-gradient(1.5px_1.5px_at_85%_85%,white,transparent)] [background-size:120px_120px]`,
  grid: `bg-[linear-gradient(rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.04)_1px,transparent_1px)] [background-size:24px_24px]`,
  flame: `bg-[radial-gradient(ellipse_at_50%_100%,rgba(255,255,255,0.12),transparent_60%)]`,
};

export function BookCover({ book, className }: Props) {
  return (
    <div
      className={cn(
        "relative aspect-[2/3] w-full overflow-hidden rounded-md shadow-2xl ring-1 ring-white/10",
        "bg-gradient-to-br",
        book.gradient,
        className
      )}
    >
      {/* Pattern overlay */}
      <div className={cn("absolute inset-0 opacity-90", patternStyles[book.pattern])} />

      {/* Top frame */}
      <div className="absolute inset-x-4 top-4 h-px bg-white/20" />
      <div className="absolute inset-x-4 top-5 h-px bg-white/10" />

      {/* Spine shadow */}
      <div className="absolute inset-y-0 left-0 w-3 bg-gradient-to-r from-black/40 to-transparent" />

      {/* Content */}
      <div className="relative flex h-full flex-col justify-between p-5">
        <div className="space-y-2">
          <div
            className={cn(
              "inline-block rounded-sm px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-white/90",
              "bg-white/10 backdrop-blur-sm"
            )}
          >
            {book.series ? book.series : book.category}
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="font-serif text-lg font-bold leading-tight text-white drop-shadow-md line-clamp-3">
            {book.title}
          </h3>
          <div className={cn("h-0.5 w-10 bg-", book.accent)} />
          <p className="text-[11px] font-medium uppercase tracking-wider text-white/60">
            {book.genre}
          </p>
        </div>

        <div className="flex items-center justify-between">
          <span className="font-serif text-xs italic text-white/70">Sado Faraji</span>
          <span className="text-[10px] font-semibold text-white/50">{book.price}</span>
        </div>
      </div>

      {/* Bottom frame */}
      <div className="absolute inset-x-4 bottom-4 h-px bg-white/20" />
      <div className="absolute inset-x-4 bottom-5 h-px bg-white/10" />

      {/* Glossy highlight */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-transparent to-white/5" />
    </div>
  );
}

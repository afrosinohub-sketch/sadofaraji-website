# Mwongozo wa Deployment — Vercel + Custom Domain

Mwongozo wa hatua kwa hatua wa ku-deploy tovuti ya Sado Faraji kwenye Vercel na kuiconnect na domain `sadofaraji.com`.

---

## Chaguo la 1: Vercel kupitia GitHub (Inapendekezwa)

### Hatua ya 1: Tengeneza Repository kwenye GitHub

1. Nenda https://github.com/new
2. Jaza:
   - **Repository name**: `sadofaraji-website` (au jina unalopendelea)
   - **Description**: `Tovuti rasmi ya Sado Faraji`
   - **Visibility**: Public au Private (yoyote)
3. Bonyeza **Create repository**

### Hatua ya 2: Push Code kutoka Project hii

```bash
cd /home/z/my-project

# Initialize git
git init
git add .
git commit -m "Initial commit: Sado Faraji website"

# Set main branch
git branch -M main

# Add remote (badilisha URL na username yako)
git remote add origin https://github.com/shiosamwanza-source/sadofaraji-website.git

# Push
git push -u origin main
```

**Kama inakusuibia authenticator:**
- Tumia recovery codes kutoka GitHub Settings → Password and authentication
- Au zima 2FA kwa muda, push code, kisha washa tena

### Hatua ya 3: Deploy kwenye Vercel

1. Nenda https://vercel.com
2. Bonyeza **Sign Up** → **Continue with GitHub** (login na GitHub)
3. Baada ya login, bonyeza **Add New...** → **Project**
4. Import repository `sadofaraji-website`
5. Settings:
   - **Framework Preset**: Next.js (auto-detected)
   - **Build Command**: `next build` (default)
   - **Output Directory**: (default)
   - **Install Command**: `bun install` (au `npm install`)
6. Bonyeza **Deploy**

Baada ya dakika 1-2, tovuti itakuwa live kwenye:
- `https://sadofaraji-website.vercel.app` (au jina lingine)

### Hatua ya 4: Ongeza Custom Domain `sadofaraji.com`

1. Kwenye Vercel dashboard, nenda kwenye project yako
2. Bonyeza **Settings** → **Domains**
3. Weka `sadofaraji.com` → bonyeza **Add**
4. Weka tena `www.sadofaraji.com` → bonyeza **Add**
5. Vercel itakupa **DNS records** za kuongeza kwenye domain registrar yako

### Hatua ya 5: Sasisha DNS kwenye Domain Registrar

Nenda kwenye mahali uliponunua `sadofaraji.com` (mfano: Namecheap, GoDaddy, Cloudflare, Mkuza, etc.) na ongeza DNS records:

**A Record (kwa sadofaraji.com):**
```
Type:  A Record
Name:  @
Value: 76.76.21.21
```

**CNAME Record (kwa www.sadofaraji.com):**
```
Type:   CNAME Record
Name:   www
Value:  cname.vercel-dns.com
```

### Hatua ya 6: Subiri SSL Certificate

- Vercel itatengeneza SSL certificate automatically
- Inachukua dakika 5-30 baada ya DNS ku-propagate
- DNS propagation inaweza kuchukua hadi saa 24-48

### Hatua ya 7: Tumia!

Baada ya DNS propagation, tovuti yako itakuwa live kwenye:
- ✅ `https://sadofaraji.com`
- ✅ `https://www.sadofaraji.com`

---

## Chaguo la 2: Vercel CLI (Bila GitHub)

Kama unataka kuepuka GitHub kabisa:

### Hatua ya 1: Install Vercel CLI

```bash
npm install -g vercel
```

### Hatua ya 2: Login

```bash
vercel login
# Weka email: sadofaraji@gmail.com
# Fungua email yako na thibitisha
```

### Hatua ya 3: Deploy

```bash
cd /home/z/my-project
vercel
# Fanya kama inavyoongoka:
# - Set up and deploy: Y
# - Which scope: (chagua akaunti yako)
# - Link to existing project: N
# - Project name: sadofaraji-website
# - Directory: ./
# - Override settings: N
```

### Hatua ya 4: Deploy kwa Production

```bash
vercel --prod
```

### Hatua ya 5: Ongeza Domain

```bash
vercel domains add sadofaraji.com
vercel domains add www.sadofaraji.com
```

Kisha fuata hatua ya 5 na 6 kutoka Chaguo la 1.

---

## Chaguo la 3: Netlify (Badala ya Vercel)

Kama unapendelea Netlify:

1. Nenda https://netlify.com
2. Sign up na GitHub
3. **Add new site** → **Import existing project**
4. Chagua repository yako
5. Settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `out` (kwa static export) au `.next` (kwa SSR)
6. **Deploy site**
7. **Domain settings** → **Add custom domain** → `sadofaraji.com`

---

## Tatizo la Authenticator

### Kama 2FA inakusumbua:

**A. Tumia Recovery Codes:**
1. Login kwenye GitHub
2. Settings → Password and authentication
3. Recovery codes → View
4. Tumia moja (kila code inatumika mara moja)

**B. Zima 2FA kwa muda:**
1. Settings → Password and authentication
2. Disable 2FA
3. Tengeneza token: Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token
4. Weka note, expiration 90 days
5. Chagua scopes: `repo`, `workflow`
6. Copy token (huitaonekana tena!)
7. Washa 2FA tena (tumia SMS chaguo)

**C. Sakinisha SMS badala ya app:**
1. Settings → Password and authentication
2. Two-factor methods → Add → Text message
3. Weka namba yako ya simu
4. Sasa utapata codes kwa SMS

---

## Hitimisho

**Mapendekezo**: Tumia **Chaguo la 1** (GitHub + Vercel) kwa sababu:
- ✅ Bure kabisa
- ✅ Automatic deployments kila unapopush code
- ✅ Automatic HTTPS/SSL
- ✅ Custom domain support
- ✅ Inafanya kazi vizuri na Next.js

**Msaada**: Kama unakwama, wasiliana nasi.
